#!/usr/bin/env bash
# Установка Hero Keep на чистый Ubuntu/Debian-сервер.
# Использование (из папки с распакованным пакетом):
#   sudo bash install.sh <BOT_TOKEN> [домен]
# Домен по умолчанию — <ip-через-дефисы>.sslip.io (бесплатный DNS на IP сервера, HTTPS от Let's Encrypt).
set -euo pipefail

BOT_TOKEN="${1:-}"
if [[ -z "$BOT_TOKEN" ]]; then echo "Нужен токен бота: sudo bash install.sh <BOT_TOKEN> [домен]"; exit 1; fi
HERE="$(cd "$(dirname "$0")" && pwd)"
IP="$(curl -fsS4 https://api.ipify.org || hostname -I | awk '{print $1}')"
DOMAIN="${2:-${IP//./-}.sslip.io}"
APP=/opt/hero-keep
DATA=/var/lib/hero-keep

echo "==> Сервер $IP, адрес игры https://$DOMAIN"

export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates gnupg debian-keyring debian-archive-keyring apt-transport-https openssl

# Node.js 22 LTS
if ! command -v node >/dev/null || [[ "$(node -p 'process.versions.node.split(".").map(Number).reduce((a,v,i)=>a+v*[1e6,1e3,1][i],0)')" -lt 22013000 ]]; then
  echo "==> Устанавливаю Node.js 22"
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
node -v

# Caddy (HTTPS и обратный прокси)
if ! command -v caddy >/dev/null; then
  echo "==> Устанавливаю Caddy"
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y
  apt-get install -y caddy
fi

# Пользователь и файлы приложения
id -u herokeep >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin herokeep
mkdir -p "$APP" "$DATA"
rm -rf "$APP/server" "$APP/client"
cp -r "$HERE/server" "$HERE/client" "$APP/"
cd "$APP/server" && npm ci --omit=dev --no-audit --no-fund
chown -R herokeep:herokeep "$APP" "$DATA"

# Секреты — только в файле окружения на сервере
ENV_FILE=/etc/hero-keep.env
SECRET="$(grep -s '^SESSION_SECRET=' "$ENV_FILE" | cut -d= -f2- || true)"
[[ -z "$SECRET" ]] && SECRET="$(openssl rand -hex 32)"
cat > "$ENV_FILE" <<EOF
NODE_ENV=production
HOST=127.0.0.1
PORT=3001
BOT_TOKEN=$BOT_TOKEN
SESSION_SECRET=$SECRET
DB_PATH=$DATA/hero-keep.db
CLIENT_DIST=$APP/client/dist
EOF
chmod 600 "$ENV_FILE"

cat > /etc/systemd/system/hero-keep.service <<EOF
[Unit]
Description=Hero Keep game server
After=network.target

[Service]
User=herokeep
WorkingDirectory=$APP/server
EnvironmentFile=$ENV_FILE
ExecStart=/usr/bin/node $APP/server/dist/main.js
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/caddy/Caddyfile <<EOF
$DOMAIN {
  encode gzip
  reverse_proxy 127.0.0.1:3001
}
EOF

if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow 80/tcp; ufw allow 443/tcp
fi

systemctl daemon-reload
systemctl enable --now hero-keep
systemctl restart hero-keep
systemctl enable caddy
systemctl restart caddy

echo "==> Жду запуска сервера"
for i in $(seq 1 30); do curl -fsS http://127.0.0.1:3001/api/health >/dev/null 2>&1 && break; sleep 1; done
curl -fsS http://127.0.0.1:3001/api/health && echo

echo "==> Жду HTTPS-сертификат"
for i in $(seq 1 60); do curl -fsS "https://$DOMAIN/api/health" >/dev/null 2>&1 && break; sleep 2; done
curl -fsS "https://$DOMAIN/api/health" && echo || echo "HTTPS ещё не готов — проверьте: journalctl -u caddy -n 50"

echo "==> Кнопка «Играть» в боте"
curl -fsS "https://api.telegram.org/bot$BOT_TOKEN/setChatMenuButton" \
  -H 'content-type: application/json' \
  -d "{\"menu_button\":{\"type\":\"web_app\",\"text\":\"Играть\",\"web_app\":{\"url\":\"https://$DOMAIN/\"}}}" && echo
curl -fsS "https://api.telegram.org/bot$BOT_TOKEN/setMyDescription" \
  -H 'content-type: application/json' \
  -d '{"description":"Hero Keep — пошаговая RPG: собирайте героев, развивайте Королевство и спускайтесь в подземелья. Нажмите «Играть»."}' >/dev/null || true

echo
echo "ГОТОВО: https://$DOMAIN"
echo "Логи: journalctl -u hero-keep -f"
